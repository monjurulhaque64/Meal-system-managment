<?php
/* Database connection settings */
	$servername = "localhost";
    $username = "qarabicn_meals";		//put your phpmyadmin username.(default is "root")
    $password = "5uYR)L8FBz6vSCA!";			//if your phpmyadmin has a password put it here.(default is "root")
    $dbname = "qarabicn_meals";
    
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
?>